﻿/*||**********************************************||
--||   DW-AdventureWorks_Basics Creation and ETL  ||
--||   Catherine Warren, 2017-01-24 through 30    ||
--||**********************************************||
*/

-- To create the Data Warehouse from nothing, use the following code: 

Use master
If Exists (Select * from Sysdatabases Where Name = 'DWAdventureWorks_Basics')
	Begin 
	ALTER DATABASE [DWAdventureWorks_Basics] SET SINGLE_USER WITH ROLLBACK IMMEDIATE
	DROP DATABASE [DWAdventureWorks_Basics]
	End
Go
Create Database DWAdventureWorks_Basics
Go
Use [DWAdventureWorks_Basics]
Go

/*
-- NOTE: To clear out and recreate the database later, use the following code: 

Use [DWAdventureWorks_Basics]
GO

-- 1) Drop the Foreign Keys from the Data Warehouse so the data in the tables can be deleted

ALTER TABLE [dbo].[FactSalesOrders] DROP CONSTRAINT [FK_FactSalesOrders_DimProducts] 
ALTER TABLE [dbo].[FactSalesOrders] DROP CONSTRAINT [FK_FactSalesOrders_DimCustomers] 
ALTER TABLE [dbo].[FactSalesOrders] DROP CONSTRAINT [FK_FactSalesOrders_DimDates]
GO

-- 2) Clear out any old data from the Data Warehouse 

TRUNCATE Table dbo.FactSalesOrders
TRUNCATE Table dbo.DimProducts 
TRUNCATE Table dbo.DimCustomers 
TRUNCATE Table dbo.DimDates 
GO

*/

-- Create two Data Warehouse Dimension tables: Products and Customers. 
-- We're creating them empty and will fill them later. 
-- These tables will include columns for Slowly Changing Dimensions of type 2. 

Use [DWAdventureWorks_Basics]
Go

CREATE --Drop
TABLE [dbo].DimProducts (
	[ProductKey] [int] IDENTITY(1,1) NOT NULL PRIMARY KEY
	, [ProductID] [int] NOT NULL
	, [ProductName] [nVarchar](50) NOT NULL
	, [StandardListPrice] [decimal](18,4) NOT NULL
	, [ProductSubcategoryID] [int] NULL
	, [ProductSubcategoryName] [nVarchar](50) NULL
	, [ProductCategoryID] [int] NULL
	, [ProductCategoryName] [nVarchar](50) NULL
	, [StartDate] [Date] NOT NULL
	, [EndDate] [Date] NULL
	, [IsCurrent] [nvarchar](1) NULL DEFAULT('Y')
);
GO


-- Create DimCustomers

Use [DWAdventureWorks_Basics]
GO

CREATE --Drop
TABLE [DWAdventureWorks_Basics].[dbo].DimCustomers (
	[CustomerKey] [int] IDENTITY(1,1) NOT NULL PRIMARY KEY
  ,	[CustomerID] [int] NOT NULL
  , [CustomerFullName] [nVarchar](100) NOT NULL
  , [CustomerCityName] [nVarchar](50) NULL
  , [CustomerStateProvinceName] [nVarchar](50) NULL
  , [CustomerCountryRegionCode] [nVarchar](50) NULL
  , [CustomerCountryRegionName] [nVarchar](50) NULL
  , [StartDate] [Date] NOT NULL
  , [EndDate] [Date] NULL
  , [IsCurrent] [nvarchar](1) NULL DEFAULT('Y')
);
GO


-- Create the DimDates table. 

USE [DWAdventureWorks_Basics]
GO

CREATE -- DROP 
TABLE [dbo].DimDates (
	[DateKey] [int] NOT NULL PRIMARY KEY
	, [FullDate] [datetime] NOT NULL
	, [FullDateName] [nVarchar](50) NOT NULL
	, [MonthID] [int] NOT NULL
	, [MonthName] [nVarchar](50) NOT NULL
	, [YearID] [int] NOT NULL
	, [YearName] [nVarchar](50) NOT NULL
 ) ON [PRIMARY]
 GO

-- Populate DimDates Table in Data Warehouse using start and end dates as found in the source data

DECLARE @StartDate datetime = '2005-07-01' 
DECLARE @EndDate datetime = '2008-07-31'
-- Use a while loop to add dates to the table 

DECLARE @DateInProcess datetime 
SET @DateInProcess = @StartDate 
WHILE @DateInProcess < = @EndDate 
BEGIN 
-- Add a row into the date dimension table for this date 

INSERT INTO [dbo].DimDates (   
 [DateKey] 
 , [FullDate]
 , [FullDateName]
 , [MonthID]
 , [MonthName] 
 , [YearID] 
 , [YearName] 
 ) 
 VALUES ( 
 -- [DateKey]
 Convert(int, @DateInProcess, 112)
-- [FullDate]
, Cast(@DateInProcess AS datetime)
 -- [FullDateName] 
 , Convert(nVarchar(50), @DateInProcess, 110) + ', '  + DateName( weekday, @DateInProcess ) 
 -- [MonthID] 
 , Month( @DateInProcess ) 
 -- [MonthName] 
 , Cast(DateName( month, @DateInProcess ) AS nVarchar(50) )
 -- [YearID] 
 , Year(@DateInProcess) 
 -- [YearName] 
 , Cast( Year(@DateInProcess) AS nVarchar(50) ) )
 -- Add a day and loop again 
 
 SET @DateInProcess = DateAdd(d, 1, @DateInProcess) 
 END

-- Create NULL value for DimDates table

USE [DWAdventureWorks_Basics]
GO

INSERT INTO [DWAdventureWorks_Basics].[dbo].[DimDates] (   
[DateKey] - This is normally added automatically 
, [FullDate]
, [FullDateName] 
, [MonthID] 
, [MonthName] 
, [YearID] 
, [YearName] 
) 
VALUES 
( -1 -- This will be the Primary key for the ﬁrst lookup value  
, -1
, 'Unknown Day' 
, -1 
, 'Unknown Month'  
, -1
, 'Unknown Year' 
) ;
GO

-- Create an empty Fact Table for SalesOrders. 

CREATE --Drop
TABLE [dbo].FactSalesOrders (
	  [SalesOrderID] [int] NOT NULL
	  , [SalesOrderDetailID] [int] NOT NULL
	  , [OrderDateKey] [int] NOT NULL
	  , [CustomerKey] [int]
	  , [ProductKey] [int]
	  , [OrderQty] [int]
	  , [ActualUnitPrice] [decimal](18,4)
) ON [PRIMARY]
GO

-- Now, add foreign keys!

ALTER TABLE [DWAdventureWorks_Basics].[dbo].FactSalesOrders ADD CONSTRAINT
	fkFactSalesOrdersToDimProducts FOREIGN KEY (ProductKey) 
	REFERENCES dbo.DimProducts	(ProductKey);

ALTER TABLE [DWAdventureWorks_Basics].[dbo].FactSalesOrders ADD CONSTRAINT 
	fkFactSalesOrdersToDimCustomers FOREIGN KEY (CustomerKey) 
	REFERENCES dbo.DimCustomers (CustomerKey);

ALTER TABLE [DWAdventureWorks_Basics].[dbo].FactSalesOrders ADD CONSTRAINT
	fkFactSalesOrderDateToDimDates FOREIGN KEY (OrderDateKey) 
	REFERENCES dbo.DimDates(DateKey);

/*
Next, go to the SSIS package and execute the two Data Flow tasks to fill 
DimProducts and DimCustomers with data. 

Test changing a Customer in the source database: 

Use [AdventureWorks_Basics]
Update Customer set firstname = 'John' where CustomerID = 11000;
GO

Use [DWAdventureWorks_Basics]
Select * from DimCustomers where CustomerID = 11000;
GO


-- Here is code to populate FactSalesOrders: 

INSERT INTO [DWAdventureWorks_Basics].[dbo].FactSalesOrders
	([SalesOrderID], [SalesOrderDetailID], [OrderDateKey], [CustomerKey], [ProductKey]
	, [OrderQty], [ActualUnitPrice] )
	SELECT
	  [SalesOrderID] = CAST(OH.[SalesOrderID] AS int) 
	  , [SalesOrderDetailID] = CAST(OD.[SalesOrderDetailID] AS int)
	  , [OrderDateKey] = CAST(DimD.[DateKey] AS int)
	  , [CustomerKey] = DimC.[CustomerKey] 
	--  , [CustomerID] = CAST(OH.[CustomerID] AS int)
	  , [ProductKey] = DimP.[ProductKey]
	--  , [ProductID] = CAST(OD.[ProductID] AS int)
	  , [OrderQty] = CAST(OD.[OrderQty] AS int)
	  , [ActualUnitPrice] = CAST(OD.[UnitPrice] AS decimal (18,4) )
	FROM [AdventureWorks_Basics].[dbo].SalesOrderHeader AS OH 
		JOIN [AdventureWorks_Basics].[dbo].SalesOrderDetail AS OD
			ON OH.[SalesOrderID] = OD.[SalesOrderID]
		JOIN [DWAdventureWorks_Basics].[dbo].[DimDates] AS DimD
			ON OH.[OrderDate] = DimD.[FullDate]
		JOIN [DWAdventureWorks_Basics].[dbo].[DimCustomers] AS DimC
			ON OH.[CustomerID] = DimC.[CustomerID]
		JOIN [DWAdventureWorks_Basics].[dbo].[DimProducts] AS DimP
			ON OD.[ProductID] = DimP.[ProductID]


-- After running the SSIS package, your data warehouse is filled with beautiful data!

*/